import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NopalSelenium1 {
    
    
    /** Pruebas con selenium Webdriver sobre la página BenditoNopal
     * Abre la página BenditoNopal, clica y vuelve atrás sobre cada uno
     * de los enlaces del menú
     * @param args
     * @throws Exception
     * @author Jorge Domínguez
     */
    public static void main(String[] args) throws Exception {
        
        System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe"); //Indica el driver del navegador

        WebDriver driver = new ChromeDriver(); //Crea un objeto
        driver.get("https://benditonopal.es/"); //Abre la página donde se realizan las pruebas
        driver.manage().window().maximize(); //Maximiza la pantalla
        Thread.sleep(3000);

        driver.findElement(By.id("menu-item-347")).click(); //Busca y clica sobre el enlace
        Thread.sleep(3000);

        driver.navigate().back(); //Vuelve atrás
        Thread.sleep(2000);

        driver.findElement(By.id("menu-item-348")).click();
        Thread.sleep(3000);

        driver.navigate().back();
        Thread.sleep(2000);

        driver.findElement(By.id("menu-item-349")).click();
        Thread.sleep(3000);

        driver.navigate().back();
        Thread.sleep(2000);

        driver.findElement(By.id("menu-item-350")).click();
        Thread.sleep(3000);

        driver.navigate().back();
        Thread.sleep(2000);

        driver.findElement(By.id("menu-item-351")).click();
        Thread.sleep(3000);

        driver.navigate().back();
        Thread.sleep(2000);

        driver.findElement(By.id("menu-item-352")).click();
        Thread.sleep(3000);

        driver.navigate().back();
        Thread.sleep(2000);

        driver.findElement(By.id("menu-item-353")).click();
        Thread.sleep(3000);

        driver.navigate().back();
        Thread.sleep(2000);

        driver.findElement(By.id("menu-item-354")).click();
        Thread.sleep(3000);

        driver.navigate().back();
        Thread.sleep(2000);
        
        driver.findElement(By.id("menu-item-355")).click();
        Thread.sleep(3000);

        driver.navigate().back();
        Thread.sleep(2000);

        driver.findElement(By.id("menu-item-427")).click();
        Thread.sleep(3000);

        driver.navigate().back();
        Thread.sleep(2000);

        driver.quit(); //Cierra el navegador
    }
}
