import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NopalSelenium2 {
    
    
    /** Pruebas con selenium Webdriver sobre la página BenditoNopal
     * @param args
     * @throws Exception
     * @author Jorge Domínguez
     */
    public static void main(String[] args) throws Exception {
        
        System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe"); //Indica el driver del navegador

        WebDriver driver = new ChromeDriver(); //Crea un objeto
        driver.get("https://benditonopal.es/"); //Abre la página donde se realizan las pruebas
        driver.manage().window().maximize(); //Maximiza la pantalla
        Thread.sleep(2000);

        driver.findElement(By.id("menu-item-353")).click(); //Busca y clica sobre el enlace
        Thread.sleep(2000);

        driver.findElement(By.id("cn-accept-cookie")).click(); //Aceptar las cookies

        driver.findElement(By.linkText("Mezcal Bruxo 1 Espadin")).click();//Seleccionar un producto
        Thread.sleep(2000);

        driver.findElement(By.name("add-to-cart")).click();//Añadir al carrito
        Thread.sleep(2000);

        driver.findElement(By.linkText("Ver carrito")).click();
        Thread.sleep(2000);

        driver.findElement(By.linkText("Finalizar compra")).click();
        Thread.sleep(2000);

        driver.findElement(By.linkText("Haz clic aquí para acceder")).click();
        Thread.sleep(2000);

        WebElement searchBox = driver.findElement(By.id("username"));//Guarda en "searchBox" la ubicación de nombre de usuario
        WebElement searchPassword = driver.findElement(By.id("password"));//Guarda en "searchPassword" la ubicación de la contraseña
        WebElement searchButton = driver.findElement(By.name("login"));//Guarda en "searchButton" la ubiación del botón "Acceder"

        Thread.sleep(2000);

        searchBox.sendKeys("jorgeadominguezgonzalez@gmail.com");//Envía los datos parametrizados a nombre de usuario
        searchPassword.sendKeys("123456Jorge");//Envía los datos parametrizados a contraseña
        searchButton.click();//Pulsa el botón "Acceder"
        Thread.sleep(2000);

        driver.quit(); //Cierra el navegador
    }
}
