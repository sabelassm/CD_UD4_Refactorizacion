import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Pruebas con JUnit sobre la página BenditoNopal
 * @author Jorge Domínguez
 */
public class NopalJunit3 {

    private WebDriver driver;

    @Before
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", "C:/Entornos de desarrollo/ChromeDriver/chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void Enlaces(){

        driver.get("https://benditonopal.es/"); // abre la página donde se realizan las pruebas
        driver.manage().window().maximize(); //Maximiza la pantalla

        driver.findElement(By.id("menu-item-347")).click(); //Busca y clica sobre el enlace

        driver.findElement(By.id("cn-accept-cookie")).click(); //Aceptar las cookies

        driver.findElement(By.linkText("¿Olvidaste la contraseña?")).click();

        WebElement searchMail = driver.findElement(By.id("user_login"));//Guarda en "searchMail" los datos del usuario

        searchMail.sendKeys("jorgeadominguezgonzalez@gmail.com");//Rellena los datos del usuario

        driver.findElement(By.name("wc_reset_password")).click();
        //Debería clicar en restablecer contraseña, aunque no conseguí que funcione
    }

    /**
     * Fin de la prueba
     */
    @After
    public void shutdown(){
        driver.quit();
    }
}
