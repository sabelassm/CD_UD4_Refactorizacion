import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NopalSelenium3 {

    
    /** Pruebas con selenium Webdriver sobre la página BenditoNopal
     * @param args
     * @throws Exception
     * @author Jorge Domínguez
     */
    public static void main(String[] args) throws Exception {
        
        System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe"); //Indica el driver del navegador

        WebDriver driver = new ChromeDriver(); //Crea un objeto
        driver.get("https://benditonopal.es/"); //Abre la página donde se realizan las pruebas
        driver.manage().window().maximize(); //Maximiza la pantalla
        Thread.sleep(2000);

        driver.findElement(By.id("menu-item-347")).click(); //Busca y clica sobre el enlace
        Thread.sleep(2000);

        driver.findElement(By.id("cn-accept-cookie")).click(); //Aceptar las cookies

        driver.findElement(By.linkText("¿Olvidaste la contraseña?")).click();
        Thread.sleep(2000);

        WebElement searchMail = driver.findElement(By.id("user_login"));//Guarda en "searchMail" los datos del usuario

        searchMail.sendKeys("jorgeadominguezgonzalez@gmail.com");//Rellena los datos del usuario
        Thread.sleep(2000);

        driver.findElement(By.name("wc_reset_password")).click();
        //Debería clicar en restablecer contraseña, aunque no conseguí que funcione

        driver.quit();
    }
    
}
