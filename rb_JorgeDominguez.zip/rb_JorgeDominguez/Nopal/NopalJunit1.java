import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Pruebas con JUnit sobre la página BenditoNopal
 * @author Jorge Domínguez
 */

public class NopalJunit1 {
    
    private WebDriver driver;

    @Before
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", "C:/Entornos de desarrollo/ChromeDriver/chromedriver.exe");
        driver = new ChromeDriver();
    }

    /**
     * Abre la página BenditoNopal, clica y vuelve atrás sobre cada uno
     * de los enlaces del menú
     */
    @Test
    public void Enlaces(){

        driver.get("https://benditonopal.es/"); // abre la página donde se realizan las pruebas
        driver.manage().window().maximize(); //Maximiza la pantalla

        driver.findElement(By.id("menu-item-347")).click(); //Busca y clica sobre el enlace
       
        driver.navigate().back(); //Vuelve atrás
       
        driver.findElement(By.id("menu-item-348")).click();
        
        driver.navigate().back();
        
        driver.findElement(By.id("menu-item-349")).click();
        
        driver.navigate().back();
        
        driver.findElement(By.id("menu-item-350")).click();
        
        driver.navigate().back();
        
        driver.findElement(By.id("menu-item-351")).click();
        
        driver.navigate().back();
        
        driver.findElement(By.id("menu-item-352")).click();
        
        driver.navigate().back();
       
        driver.findElement(By.id("menu-item-353")).click();
        
        driver.navigate().back();
        
        driver.findElement(By.id("menu-item-354")).click();
        
        driver.navigate().back();
        
        driver.findElement(By.id("menu-item-355")).click(); 

        driver.navigate().back();
        
        driver.findElement(By.id("menu-item-427")).click();
        
        driver.navigate().back();
    }

    /**
     * Fin de la prueba
     */
    @After
    public void shutdown(){
        driver.quit();
    }
}
