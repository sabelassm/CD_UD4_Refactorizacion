import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Pruebas con JUnit sobre la página BenditoNopal
 * @author Jorge Domínguez
 */
public class NopalJunit2 {

    private WebDriver driver;

    @Before
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", "C:/Entornos de desarrollo/ChromeDriver/chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void Enlaces(){

        driver.get("https://benditonopal.es/"); // abre la página donde se realizan las pruebas
        driver.manage().window().maximize(); //Maximiza la pantalla

        driver.findElement(By.id("menu-item-353")).click(); //Busca y clica sobre el enlace

        driver.findElement(By.id("cn-accept-cookie")).click(); //Aceptar las cookies

        driver.findElement(By.linkText("Mezcal Bruxo 1 Espadin")).click();//Seleccionar un producto

        driver.findElement(By.name("add-to-cart")).click();//Añadir al carrito

        driver.findElement(By.linkText("Ver carrito")).click();

        driver.findElement(By.linkText("Finalizar compra")).click();

        driver.findElement(By.linkText("Haz clic aquí para acceder")).click();

        WebElement searchBox = driver.findElement(By.id("username"));//Guarda en "searchBox" la ubicación de nombre de usuario
        WebElement searchPassword = driver.findElement(By.id("password"));//Guarda en "searchPassword" la ubicación de la contraseña
        WebElement searchButton = driver.findElement(By.name("login"));//Guarda en "searchButton" la ubiación del botón "Acceder"

        searchBox.sendKeys("jorgeadominguezgonzalez@gmail.com");//Envía los datos parametrizados a nombre de usuario
        searchPassword.sendKeys("123456Jorge");//Envía los datos parametrizados a contraseña
        searchButton.click();//Pulsa el botón "Acceder"
    }

    /**
     * Fin de la prueba
     */
    @After
    public void shutdown(){
        driver.quit();
    }
    
}
