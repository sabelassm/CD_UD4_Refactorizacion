import sonarPrueba.Circulito;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Pruebas para la clase Circulito
 * @author profesor
 */
public class CirculoTest {

    /**
     * Test del método setX de la clase <Circulito>
     */
    @Test
    public void testset() {
        System.out.println("setX");
        int valorX = 0;
        Circulito instance = new Circulito();
        instance.setX(valorX);
    }

    /**
     * Test del método setY de la clase <Circulito>
     */
    @Test
    public void testsetY() {
        System.out.println("setY");
        int valorY = 0;
        Circulito instance = new Circulito();
        instance.setY(valorY);
    }

    /**
     * Test del método setRadio de la clase <Circulito>
     */
    @Test
    public void testEstablecerRadio(){
        System.out.println("setRadio");
        Circulito instance = new Circulito();
        instance.setRadio(0.0);
        instance.setRadio(0.1);
        instance.setRadio(-0.1);
    }

    /**
     * Test del método getX de la clase <Circulito>
     */
    @Test
    public void testgetX() {
        System.out.println("getX");
        Circulito instance = new Circulito(0,0,0.1);
        int expResult = 0;
        int result = instace.getX();
        assertEquals(expResult, result);
    }

    /**
     * Test del método getY de la clase <Circulito>
     */
    @Test
    public void testgetY() {
        System.out.println("getY");
        Circulito instance = new Circulito(0,0,0.1);
        int expResult = 0;
        int result = instance.getY();
        assertEquals(expResult, result);
    }

    /**
     * Test del método getRadio de la clase <Circulito>
     */
    @Test
    public void testgetRadio() {
        System.out.println("getRadio");
        Circulito instance = new Circulito(0,0,0.1);
        double result = instance.getRadio();
        assertEquals(0.1, result,0);

        instance.setRadio(0.1);
        result = instance.getRadio();
        assertEquals(0.0, result,0);
    }

    /**
     * Test del método obtenerDiametro de la clase <Circulito>
     */
    @Test
    public void testObtenerDiametro() {
        System.out.println("obtenerDiametro");
        Circulito instance = new Circulito(0,0,0.1);
        double result = instance.obtenerDiametro();
        assertEquals(0.2, result,0);
    }

    /**
     * Test del método obtenerCircunferencia de la clase <Circulito>
     */
    @Test
    public void testObtenerCircunferencia() {
        System.out.println("obtenerCircunferencia");
        Circulito instance = new Circulito(0,0,0.1);
        double expResult = 0.6283185;
        double result = instance.obtenerCircunferencia();
        assertEquals(expResult, result,1e-6);
    }

    /**
     * Test del método obtenerArea de la clase <Circulito>
     */
    @Test
    public void testObtenerArea() {
        System.out.println("obtenerArea");
        Circulito instance = new Circulito(0,0,0.1);
        double expResult = 0.0314159;
        double result = instance.obtenerAreaCirculo();
        assertEquals(expResult, result, 1e-6);
    }

    /**
     * Test del método trasladarCentro de la clase <Circulito>
     */
    @Test
    public void testTrasladarCentro() {
        System.out.println("trasladarCentro");
        Circulito instance = new Circulito();
        int resultx = instance.getX();
        int resulty = instance.getY();
        instance.trasladarCentro();
        int resultnx = instance.getX();
        int resultny = instance.getY();
        assertEquals(resultx + 5, resultnx);
        assertEquals(resulty + 6, resultny);
    }
}
