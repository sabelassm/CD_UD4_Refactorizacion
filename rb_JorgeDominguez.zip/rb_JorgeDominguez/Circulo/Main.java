import java.text.DecimalFormat;

/**
 * Pruebas de refactorización en Netbeans con la clase Circulito
 * @author profesor
 */
public class Main {
   
    /**
     * Crea un objeto <circulito> con los valores parametrizados
     * Establece el formato de salida por pantalla
     * Imprime por pantalla los cálculos realizados
     * @param args
     */
    public static void main(String[] args) {
        Circulito Circulito = new Circulito(37,43,2.5);
        String salida =
                "La coordenada X es "+Circulito.getX()+
                "\nLa coordenada Y es "+Circulito.getY()+
                "\nEl radio es "+Circulito.getRadio();
        Circulito.setX(35);
        Circulito.setY(20);
        Circulito.setRadio(4.2);
        DecimalFormat dosDigitos = new DecimalFormat("0.00");
        salida += "\nEl diámetro es "+dosDigitos.format(Circulito.obtenerDiametro());
        salida += "\nLa circunferencia es "+dosDigitos.format(Circulito.obtenerCircunferencia());
        salida += "\nEl área es "+dosDigitos.format(Circulito.obtenerAreaCirculo());
        System.out.println(salida);

        System.out.println(salida);
        System.exit(0);
    }
}
