/**
 * Pruebas de refactorización en Netbeans con la clase Circulito
 * @author profesor
 *
 */
public class Cirulito {

    private static final double valorCero = 0.0;
    private static final double Cero = 0.0;
    private int coordenadaX;
    private int coordenadaY;
    private double radio;
    private final double LIMITERADIO = 0.0;

    /**
     * Constructor vacío
     */
    /**public Circulito() {
    }*/

    /**
     * Asigna los valores parametrizados a las variables
     * @param valorcoordenadaX
     * @param valorcoordenadaY
     * @param valorRadio
     */
    public Circulito(int valorcoordenadaX, int valorcoordenadaY, double valorRadio){
        coordenadaX = valorcoordenadaX;
        coordenadaY = valorcoordenadaY;
        setRadio(valorRadio);
    }

    /**
     * Asigna el valor parametrizado a la variable
     * @param valorcoordenadaX
     */
    public void setX(int valorcoordenadaX) {
        coordenadaX = valorcoordenadaX;
    }

    /**
     * Devuelve el valor de <coordenadaX>
     * @return coordenadaX
     */
    public int getX() {
        return coordenadaX;
    }

    /**
     * Asigna el valor parametrizado a la variable
     * @param valorcooredenadaY
     */
    public void setY(int valorcoordenadaY) {
        coordenadaY = valorcoordenadaY;
    }

    /**
     * Devuelve el valor <coordenadaY>
     * @return coordenadaY
     */
    public int getY() {
        return coordenadaY;
    }
    
    /**
     * Asigna el valor parametrizado a la variable
     * Si <valorRadio> es menor que <cero> entonces asigna <cero>
     * sino asigna <valorRadio>
     * @param valorRadio
     */
    public void setRadio(double valorRadio) {
        radio=(valorRadio < cero ? valorCero : valorRadio);
    }

    /**
     * Devuelve el valor de <radio>
     * @return <radio>
     */
    public double getRadio() {
        return radio;
    }

    /**
     * Devuelve el diámetro del círculo
     * @return radio * 2
     */
    public double obtenerDiametro() {
        return radio * 2;
    }

    /**
     * Devuelve la circunferencia del círculo
     * @return PI * (radio*2)
     */
    public double obtenerCircunferencia() {
        return Math.PI * obtenerDiametro();
    }

    /**
     * Devuelve el área del círculo
     * @return PI * (radio*radio)
     */
    public double obtenerAreaCirculo() {
        return Math.PI * radio * radio;
    }

    /**
     * Establece el formato de salida por pantalla
     */
    @Override
    public String toString() {
        return "Centro = [" + coordenadaX + "," + cooredenadaY + "]; Radio = " + radio;
    }

    /**
     * Suma 5 a cada variable
     */
    public void trasladarCentro() {
        coordenadaX = coordenadaX + 5;
        coordenadaY = coordenadaY + 5;
    }

    /**
     * Devuelve el valor de la variable <coordenadaX>
     * @return <coordenadaX>
     */
    public int a() {
        return coordenadaX;
    }
}
